import React, { useState } from 'react';
import { useLanguage } from '../components/LanguageContext';
import { base44 } from 'api/base44';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { 
  Leaf, 
  Droplets,
  Beaker,
  Sparkles,
  Loader2,
  ChevronRight,
  CheckCircle,
  AlertCircle,
  Wheat,
  Info
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from 'components/ui/card';
import Badge from 'components/ui/badge';
import Button from 'components/ui/button';
import Input from 'components/ui/input';
import Label from 'components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from 'components/ui/select';
import Slider from 'components/ui/slider';
import { format } from 'date-fns';

export default function SoilAdvisory() {
  const { t, language } = useLanguage();
  const queryClient = useQueryClient();
  
  const [soilData, setSoilData] = useState({
    ph_level: 7,
    nitrogen_level: 'medium',
    phosphorus_level: 'medium',
    potassium_level: 'medium',
    organic_matter: 'medium',
    moisture_content: 50,
    soil_type: ''
  });

  const { data: farms } = useQuery({
    queryKey: ['farms'],
    queryFn: () => base44.entities.Farm.list('-created_date', 10),
    initialData: []
  });

  const { data: analyses } = useQuery({
    queryKey: ['soil-analyses'],
    queryFn: () => base44.entities.SoilAnalysis.list('-created_date', 5),
    initialData: []
  });

  const analyzeMutation = useMutation({
    mutationFn: async (data) => {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `As an agricultural soil expert, analyze these soil parameters for farming in Karnataka, India:
        
Soil Parameters:
- pH Level: ${data.ph_level}
- Nitrogen Level: ${data.nitrogen_level}
- Phosphorus Level: ${data.phosphorus_level}
- Potassium Level: ${data.potassium_level}
- Organic Matter: ${data.organic_matter}
- Moisture Content: ${data.moisture_content}%
- Soil Type: ${data.soil_type || 'Not specified'}

Provide:
1. Detailed recommendations in English (2-3 paragraphs covering fertilizers, amendments, and practices)
2. Same recommendations in Kannada
3. List of 5-7 most suitable crops for this soil condition`,
        response_json_schema: {
          type: "object",
          properties: {
            recommendations: { type: "string" },
            recommendations_kannada: { type: "string" },
            suitable_crops: { type: "array", items: { type: "string" } }
          }
        }
      });
      
      const analysisData = {
        ...data,
        ...result,
        farm_id: farms[0]?.id || ''
      };
      
      await base44.entities.SoilAnalysis.create(analysisData);
      return analysisData;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['soil-analyses'] });
    }
  });

  const getLevelColor = (level) => {
    const colors = {
      low: 'bg-red-100 text-red-700 border-red-200',
      medium: 'bg-amber-100 text-amber-700 border-amber-200',
      high: 'bg-green-100 text-green-700 border-green-200'
    };
    return colors[level] || colors.medium;
  };

  const getPhColor = (ph) => {
    if (ph < 5.5) return 'text-red-600';
    if (ph < 6.5) return 'text-amber-600';
    if (ph <= 7.5) return 'text-green-600';
    if (ph <= 8.5) return 'text-amber-600';
    return 'text-red-600';
  };

  const getPhStatus = (ph) => {
    if (ph < 5.5) return language === 'kn' ? 'ಅತಿ ಆಮ್ಲೀಯ' : 'Too Acidic';
    if (ph < 6.5) return language === 'kn' ? 'ಸ್ವಲ್ಪ ಆಮ್ಲೀಯ' : 'Slightly Acidic';
    if (ph <= 7.5) return language === 'kn' ? 'ಸಮತೋಲಿತ' : 'Optimal';
    if (ph <= 8.5) return language === 'kn' ? 'ಸ್ವಲ್ಪ ಕ್ಷಾರೀಯ' : 'Slightly Alkaline';
    return language === 'kn' ? 'ಅತಿ ಕ್ಷಾರೀಯ' : 'Too Alkaline';
  };

  const soilTypes = [
    { value: 'black_soil', label: t('black_soil') },
    { value: 'red_soil', label: t('red_soil') },
    { value: 'alluvial', label: t('alluvial') },
    { value: 'laterite', label: t('laterite') },
    { value: 'sandy', label: t('sandy') },
    { value: 'clay', label: t('clay') }
  ];

  const levels = [
    { value: 'low', label: t('low') },
    { value: 'medium', label: t('medium') },
    { value: 'high', label: t('high') }
  ];

  return (
    <div className="space-y-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <div className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-100 text-emerald-700 rounded-full text-sm font-medium mb-4">
          <Sparkles className="w-4 h-4" />
          {language === 'kn' ? 'AI-ಚಾಲಿತ ವಿಶ್ಲೇಷಣೆ' : 'AI-Powered Analysis'}
        </div>
        <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-3">{t('soilTitle')}</h1>
        <p className="text-gray-600 max-w-2xl mx-auto">
          {language === 'kn' 
            ? 'ನಿಮ್ಮ ಮಣ್ಣಿನ ಮಾದರಿಗಳನ್ನು ನಮೂದಿಸಿ ಮತ್ತು ವೈಯಕ್ತಿಕ ಶಿಫಾರಸುಗಳನ್ನು ಪಡೆಯಿರಿ'
            : 'Enter your soil parameters and get personalized recommendations for better yields'}
        </p>
      </motion.div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Input Form */}
        <Card className="border-0 shadow-xl">
          <CardHeader className="bg-gradient-to-r from-emerald-500 to-teal-500 text-white rounded-t-xl">
            <CardTitle className="flex items-center gap-2">
              <Beaker className="w-5 h-5" />
              {language === 'kn' ? 'ಮಣ್ಣಿನ ಮಾದರಿಗಳನ್ನು ನಮೂದಿಸಿ' : 'Enter Soil Parameters'}
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6 space-y-6">
            {/* Soil Type */}
            <div className="space-y-2">
              <Label className="text-gray-700 font-medium">{t('soilType')}</Label>
              <Select
                value={soilData.soil_type}
                onValueChange={(value) => setSoilData({ ...soilData, soil_type: value })}
              >
                <SelectTrigger className="h-12">
                  <SelectValue placeholder={language === 'kn' ? 'ಮಣ್ಣಿನ ಪ್ರಕಾರವನ್ನು ಆಯ್ಕೆಮಾಡಿ' : 'Select soil type'} />
                </SelectTrigger>
                <SelectContent>
                  {soilTypes.map((type) => (
                    <SelectItem key={type.value} value={type.value}>{type.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* pH Level */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label className="text-gray-700 font-medium">{t('phLevel')}</Label>
                <span className={`text-lg font-bold ${getPhColor(soilData.ph_level)}`}>
                  {soilData.ph_level} - {getPhStatus(soilData.ph_level)}
                </span>
              </div>
              <Slider
                value={[soilData.ph_level]}
                onValueChange={(value) => setSoilData({ ...soilData, ph_level: value[0] })}
                min={4}
                max={10}
                step={0.1}
                className="py-4"
              />
              <div className="flex justify-between text-xs text-gray-500">
                <span>{language === 'kn' ? 'ಆಮ್ಲೀಯ' : 'Acidic'}</span>
                <span>{language === 'kn' ? 'ತಟಸ್ಥ' : 'Neutral'}</span>
                <span>{language === 'kn' ? 'ಕ್ಷಾರೀಯ' : 'Alkaline'}</span>
              </div>
            </div>

            {/* NPK Levels */}
            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label className="text-gray-700 font-medium">{t('nitrogen')}</Label>
                <Select
                  value={soilData.nitrogen_level}
                  onValueChange={(value) => setSoilData({ ...soilData, nitrogen_level: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {levels.map((level) => (
                      <SelectItem key={level.value} value={level.value}>{level.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label className="text-gray-700 font-medium">{t('phosphorus')}</Label>
                <Select
                  value={soilData.phosphorus_level}
                  onValueChange={(value) => setSoilData({ ...soilData, phosphorus_level: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {levels.map((level) => (
                      <SelectItem key={level.value} value={level.value}>{level.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label className="text-gray-700 font-medium">{t('potassium')}</Label>
                <Select
                  value={soilData.potassium_level}
                  onValueChange={(value) => setSoilData({ ...soilData, potassium_level: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {levels.map((level) => (
                      <SelectItem key={level.value} value={level.value}>{level.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Organic Matter */}
            <div className="space-y-2">
              <Label className="text-gray-700 font-medium">{t('organicMatter')}</Label>
              <Select
                value={soilData.organic_matter}
                onValueChange={(value) => setSoilData({ ...soilData, organic_matter: value })}
              >
                <SelectTrigger className="h-12">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {levels.map((level) => (
                    <SelectItem key={level.value} value={level.value}>{level.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Moisture */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label className="text-gray-700 font-medium">{t('moisture')}</Label>
                <span className="text-lg font-bold text-blue-600">{soilData.moisture_content}%</span>
              </div>
              <Slider
                value={[soilData.moisture_content]}
                onValueChange={(value) => setSoilData({ ...soilData, moisture_content: value[0] })}
                min={0}
                max={100}
                step={1}
                className="py-4"
              />
            </div>

            <Button
              onClick={() => analyzeMutation.mutate(soilData)}
              disabled={analyzeMutation.isPending}
              className="w-full bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white py-6 text-lg rounded-xl"
            >
              {analyzeMutation.isPending ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  {t('analyzing')}
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5 mr-2" />
                  {language === 'kn' ? 'ಶಿಫಾರಸುಗಳನ್ನು ಪಡೆಯಿರಿ' : 'Get Recommendations'}
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Results */}
        {analyzeMutation.data ? (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
          >
            <Card className="border-0 shadow-xl h-full">
              <CardHeader className="bg-gradient-to-r from-green-500 to-emerald-500 text-white rounded-t-xl">
                <CardTitle className="flex items-center gap-2">
                  <CheckCircle className="w-5 h-5" />
                  {t('recommendations')}
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-6">
                {/* Current Parameters Summary */}
                <div className="grid grid-cols-3 gap-3">
                  <div className="text-center p-3 bg-emerald-50 rounded-xl">
                    <p className="text-xs text-gray-500 mb-1">{t('nitrogen')}</p>
                    <Badge className={getLevelColor(soilData.nitrogen_level)}>
                      {t(soilData.nitrogen_level)}
                    </Badge>
                  </div>
                  <div className="text-center p-3 bg-emerald-50 rounded-xl">
                    <p className="text-xs text-gray-500 mb-1">{t('phosphorus')}</p>
                    <Badge className={getLevelColor(soilData.phosphorus_level)}>
                      {t(soilData.phosphorus_level)}
                    </Badge>
                  </div>
                  <div className="text-center p-3 bg-emerald-50 rounded-xl">
                    <p className="text-xs text-gray-500 mb-1">{t('potassium')}</p>
                    <Badge className={getLevelColor(soilData.potassium_level)}>
                      {t(soilData.potassium_level)}
                    </Badge>
                  </div>
                </div>

                {/* Recommendations */}
                <div className="p-4 bg-green-50 rounded-xl border border-green-100">
                  <h4 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                    <Info className="w-4 h-4 text-green-600" />
                    {t('recommendations')}
                  </h4>
                  <p className="text-gray-700 whitespace-pre-line">
                    {language === 'kn' 
                      ? analyzeMutation.data.recommendations_kannada 
                      : analyzeMutation.data.recommendations}
                  </p>
                </div>

                {/* Suitable Crops */}
                <div>
                  <h4 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                    <Wheat className="w-4 h-4 text-amber-600" />
                    {t('suitableCrops')}
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {analyzeMutation.data.suitable_crops?.map((crop, index) => (
                      <Badge key={index} className="bg-amber-100 text-amber-700 border border-amber-200 px-3 py-1">
                        {crop}
                      </Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ) : (
          <Card className="border-0 shadow-xl h-full flex items-center justify-center bg-gray-50">
            <CardContent className="text-center py-16">
              <div className="w-24 h-24 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <Leaf className="w-12 h-12 text-emerald-500" />
              </div>
              <h3 className="text-xl font-semibold text-gray-700 mb-2">
                {language === 'kn' ? 'ಮಾದರಿಗಳನ್ನು ನಮೂದಿಸಿ' : 'Enter soil parameters'}
              </h3>
              <p className="text-gray-500">
                {language === 'kn' 
                  ? 'ಶಿಫಾರಸುಗಳು ಇಲ್ಲಿ ಕಾಣಿಸುತ್ತವೆ'
                  : 'Recommendations will appear here'}
              </p>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Recent Analyses */}
      {analyses.length > 0 && (
        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-6">
            {language === 'kn' ? 'ಇತ್ತೀಚಿನ ವಿಶ್ಲೇಷಣೆಗಳು' : 'Recent Analyses'}
          </h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {analyses.map((analysis) => (
              <Card key={analysis.id} className="border-0 shadow-lg hover:shadow-xl transition-shadow">
                <CardContent className="p-5">
                  <div className="flex items-start justify-between mb-4">
                    <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center">
                      <Leaf className="w-6 h-6 text-emerald-600" />
                    </div>
                    <span className="text-sm text-gray-500">
                      {format(new Date(analysis.created_date), 'MMM d, yyyy')}
                    </span>
                  </div>
                  
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-500">{t('phLevel')}</span>
                      <span className={`font-semibold ${getPhColor(analysis.ph_level)}`}>
                        {analysis.ph_level}
                      </span>
                    </div>
                    
                    <div className="flex flex-wrap gap-2">
                      <Badge className={getLevelColor(analysis.nitrogen_level)}>
                        N: {t(analysis.nitrogen_level)}
                      </Badge>
                      <Badge className={getLevelColor(analysis.phosphorus_level)}>
                        P: {t(analysis.phosphorus_level)}
                      </Badge>
                      <Badge className={getLevelColor(analysis.potassium_level)}>
                        K: {t(analysis.potassium_level)}
                      </Badge>
                    </div>
                    
                    {analysis.suitable_crops && (
                      <p className="text-sm text-gray-600 line-clamp-2">
                        {t('suitableCrops')}: {analysis.suitable_crops.slice(0, 3).join(', ')}
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}