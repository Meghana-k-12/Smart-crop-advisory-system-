import React, { useState } from 'react';
import { useLanguage } from '../components/LanguageContext';
import { base44 } from 'api/base44';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { 
  TrendingUp, 
  TrendingDown,
  Search,
  Wheat,
  BarChart3,
  ArrowUpRight,
  ArrowDownRight,
  Minus,
  Loader2,
  RefreshCw,
  IndianRupee,
  Package
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from 'components/ui/card';
import Badge from 'components/ui/badge';
import Input from 'components/ui/input';
import Button from 'components/ui/button';
import { format } from 'date-fns';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area
} from 'recharts';

export default function MarketPrices() {
  const { t, language } = useLanguage();
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState('');

  const { data: prices, isLoading } = useQuery({
    queryKey: ['market-prices'],
    queryFn: () => base44.entities.MarketPrice.list('-created_date', 50),
    initialData: []
  });

  const refreshMutation = useMutation({
    mutationFn: async () => {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Generate realistic current market prices for agricultural commodities in Karnataka, India. Include 10 common crops with:
- Crop name in English
- Crop name in Kannada
- Current price per quintal in INR (realistic 2024 prices)
- Previous price (for comparison)
- Market name (major mandis in Karnataka like Hubli, Belgaum, Dharwad, Mysore)
- Trend (rising, falling, or stable)
- Demand level (low, medium, high, very_high)
- Today's date`,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            prices: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  crop_name: { type: "string" },
                  crop_name_kannada: { type: "string" },
                  price_per_quintal: { type: "number" },
                  previous_price: { type: "number" },
                  market_name: { type: "string" },
                  trend: { type: "string" },
                  demand: { type: "string" },
                  date_recorded: { type: "string" }
                }
              }
            }
          }
        }
      });
      
      if (result.prices) {
        await base44.entities.MarketPrice.bulkCreate(result.prices);
      }
      return result;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['market-prices'] });
    }
  });

  const filteredPrices = prices.filter(price => 
    price.crop_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    price.crop_name_kannada?.includes(searchTerm) ||
    price.market_name?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getTrendIcon = (trend) => {
    if (trend === 'rising') return <ArrowUpRight className="w-5 h-5 text-green-600" />;
    if (trend === 'falling') return <ArrowDownRight className="w-5 h-5 text-red-600" />;
    return <Minus className="w-5 h-5 text-gray-400" />;
  };

  const getTrendColor = (trend) => {
    if (trend === 'rising') return 'bg-green-100 text-green-700 border-green-200';
    if (trend === 'falling') return 'bg-red-100 text-red-700 border-red-200';
    return 'bg-gray-100 text-gray-700 border-gray-200';
  };

  const getDemandColor = (demand) => {
    const colors = {
      low: 'bg-gray-100 text-gray-700',
      medium: 'bg-blue-100 text-blue-700',
      high: 'bg-amber-100 text-amber-700',
      very_high: 'bg-emerald-100 text-emerald-700'
    };
    return colors[demand] || colors.medium;
  };

  const getPriceChange = (current, previous) => {
    if (!previous) return null;
    const change = ((current - previous) / previous * 100).toFixed(1);
    return parseFloat(change);
  };

  // Prepare chart data
  const chartData = prices.slice(0, 7).map(p => ({
    name: language === 'kn' ? p.crop_name_kannada : p.crop_name,
    price: p.price_per_quintal,
    previous: p.previous_price
  })).reverse();

  // Stats
  const risingCount = prices.filter(p => p.trend === 'rising').length;
  const fallingCount = prices.filter(p => p.trend === 'falling').length;
  const avgPrice = prices.length > 0 
    ? Math.round(prices.reduce((sum, p) => sum + (p.price_per_quintal || 0), 0) / prices.length)
    : 0;

  return (
    <div className="space-y-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col md:flex-row md:items-center justify-between gap-4"
      >
        <div>
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900">{t('marketTitle')}</h1>
          <p className="text-gray-600 mt-2">
            {language === 'kn' 
              ? 'ಕರ್ನಾಟಕದ ಮಂಡಿಗಳಿಂದ ಇತ್ತೀಚಿನ ಬೆಲೆಗಳು'
              : 'Latest prices from Karnataka mandis'}
          </p>
        </div>
        <Button
          onClick={() => refreshMutation.mutate()}
          disabled={refreshMutation.isPending}
          className="bg-gradient-to-r from-blue-500 to-indigo-500 hover:from-blue-600 hover:to-indigo-600"
        >
          {refreshMutation.isPending ? (
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
          ) : (
            <RefreshCw className="w-4 h-4 mr-2" />
          )}
          {language === 'kn' ? 'ಬೆಲೆಗಳನ್ನು ನವೀಕರಿಸಿ' : 'Refresh Prices'}
        </Button>
      </motion.div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="border-0 shadow-lg bg-gradient-to-br from-blue-500 to-indigo-600 text-white">
          <CardContent className="p-5">
            <Package className="w-8 h-8 mb-3 opacity-80" />
            <p className="text-3xl font-bold">{prices.length}</p>
            <p className="text-blue-100 text-sm">{language === 'kn' ? 'ಒಟ್ಟು ಬೆಳೆಗಳು' : 'Total Crops'}</p>
          </CardContent>
        </Card>
        
        <Card className="border-0 shadow-lg bg-gradient-to-br from-green-500 to-emerald-600 text-white">
          <CardContent className="p-5">
            <TrendingUp className="w-8 h-8 mb-3 opacity-80" />
            <p className="text-3xl font-bold">{risingCount}</p>
            <p className="text-green-100 text-sm">{language === 'kn' ? 'ಏರುತ್ತಿದೆ' : 'Rising'}</p>
          </CardContent>
        </Card>
        
        <Card className="border-0 shadow-lg bg-gradient-to-br from-red-500 to-rose-600 text-white">
          <CardContent className="p-5">
            <TrendingDown className="w-8 h-8 mb-3 opacity-80" />
            <p className="text-3xl font-bold">{fallingCount}</p>
            <p className="text-red-100 text-sm">{language === 'kn' ? 'ಇಳಿಯುತ್ತಿದೆ' : 'Falling'}</p>
          </CardContent>
        </Card>
        
        <Card className="border-0 shadow-lg bg-gradient-to-br from-amber-500 to-orange-600 text-white">
          <CardContent className="p-5">
            <IndianRupee className="w-8 h-8 mb-3 opacity-80" />
            <p className="text-3xl font-bold">₹{avgPrice.toLocaleString()}</p>
            <p className="text-amber-100 text-sm">{language === 'kn' ? 'ಸರಾಸರಿ' : 'Avg Price'}</p>
          </CardContent>
        </Card>
      </div>

      {/* Chart */}
      {chartData.length > 0 && (
        <Card className="border-0 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-blue-500" />
              {language === 'kn' ? 'ಬೆಲೆ ಹೋಲಿಕೆ' : 'Price Comparison'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Tooltip 
                    formatter={(value) => [`₹${value.toLocaleString()}`, '']}
                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 20px rgba(0,0,0,0.1)' }}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="price" 
                    stroke="#3b82f6" 
                    fill="url(#colorPrice)" 
                    strokeWidth={2}
                    name={t('currentPrice')}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="previous" 
                    stroke="#94a3b8" 
                    fill="url(#colorPrev)" 
                    strokeWidth={2}
                    strokeDasharray="5 5"
                    name={language === 'kn' ? 'ಹಿಂದಿನ' : 'Previous'}
                  />
                  <defs>
                    <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                    </linearGradient>
                    <linearGradient id="colorPrev" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#94a3b8" stopOpacity={0.2}/>
                      <stop offset="95%" stopColor="#94a3b8" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
        <Input
          placeholder={language === 'kn' ? 'ಬೆಳೆ ಅಥವಾ ಮಾರುಕಟ್ಟೆ ಹುಡುಕಿ...' : 'Search crops or markets...'}
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-12 py-6 text-lg rounded-xl border-gray-200 focus:border-blue-500"
        />
      </div>

      {/* Price List */}
      {isLoading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
        </div>
      ) : filteredPrices.length === 0 ? (
        <div className="text-center py-20">
          <Wheat className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <p className="text-gray-500 text-lg">
            {language === 'kn' ? 'ಬೆಲೆಗಳು ಕಂಡುಬಂದಿಲ್ಲ' : 'No prices found'}
          </p>
          <Button
            onClick={() => refreshMutation.mutate()}
            className="mt-4"
            variant="outline"
          >
            {language === 'kn' ? 'ಬೆಲೆಗಳನ್ನು ಲೋಡ್ ಮಾಡಿ' : 'Load Prices'}
          </Button>
        </div>
      ) : (
        <div className="grid gap-4">
          {filteredPrices.map((price, index) => {
            const priceChange = getPriceChange(price.price_per_quintal, price.previous_price);
            
            return (
              <motion.div
                key={price.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <Card className="border-0 shadow-md hover:shadow-lg transition-shadow">
                  <CardContent className="p-5">
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                      <div className="flex items-center gap-4">
                        <div className="w-14 h-14 bg-emerald-100 rounded-xl flex items-center justify-center">
                          <Wheat className="w-7 h-7 text-emerald-600" />
                        </div>
                        <div>
                          <h3 className="text-lg font-bold text-gray-900">
                            {language === 'kn' ? price.crop_name_kannada || price.crop_name : price.crop_name}
                          </h3>
                          <p className="text-sm text-gray-500">{price.market_name}</p>
                        </div>
                      </div>
                      
                      <div className="flex flex-wrap items-center gap-3">
                        <Badge className={getDemandColor(price.demand)}>
                          {t(price.demand)}
                        </Badge>
                        <Badge className={`${getTrendColor(price.trend)} flex items-center gap-1`}>
                          {getTrendIcon(price.trend)}
                          {t(price.trend)}
                        </Badge>
                      </div>
                      
                      <div className="text-right">
                        <p className="text-2xl font-bold text-gray-900">
                          ₹{price.price_per_quintal?.toLocaleString()}
                        </p>
                        <p className="text-sm text-gray-500">{t('pricePerQuintal')}</p>
                        {priceChange !== null && (
                          <p className={`text-sm font-medium ${priceChange >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                            {priceChange >= 0 ? '+' : ''}{priceChange}%
                          </p>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}